zip -q -r -9 html.zip *
