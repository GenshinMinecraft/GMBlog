rm html.zip
zip -q -r -9 html.zip *
